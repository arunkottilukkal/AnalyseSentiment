# SentimentAnalysis Package

# How to use the package?

from AnalyseSentiment.AnalyseSentiment import AnalyseSentiment

obj = AnalyseSentiment()

data = obj.Analyse("sentence to be analysed")